from graphics import *
win = GraphWin("shapes")
center = Point(100,100)
center.draw(win)
